package com.intellipaat.xyz_mart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XyzMartApplicationTests {

	@Test
	void contextLoads() {
	}

}

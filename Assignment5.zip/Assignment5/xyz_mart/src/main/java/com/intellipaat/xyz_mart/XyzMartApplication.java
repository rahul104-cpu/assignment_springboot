package com.intellipaat.xyz_mart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XyzMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(XyzMartApplication.class, args);
	}

}

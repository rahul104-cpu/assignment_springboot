package com.intellipaat.xyz_mart.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.intellipaat.xyz_mart.entity.TransactionLog;

public interface TransactionLogRepository extends JpaRepository<TransactionLog, Long> {

    // You can add custom query methods if needed
}

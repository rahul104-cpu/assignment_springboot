package com.intellipaat.xyz_mart.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.intellipaat.xyz_mart.entity.Product;
import com.intellipaat.xyz_mart.repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Transactional
    public void updateProductQuantity(Long productId, int newQuantity) {
        productRepository.findById(productId).ifPresent(product -> {
            product.setQuantity(newQuantity);
            productRepository.save(product);
        });
    }
    public void deleteProduct(Long productId) {
        productRepository.deleteById(productId);
    }
    public void createProduct(Product product) {
        productRepository.save(product);
    }
    public void makePurchase(Long productId, int quantityPurchased) {
        productRepository.findById(productId).ifPresent(product -> {
            if (product.getQuantity() >= quantityPurchased) {
                product.setQuantity(product.getQuantity() - quantityPurchased);
                productRepository.save(product);

            } else {
                throw new RuntimeException("Not enough quantity available for the purchase.");
            }
        });
    }
    public void updateProduct(Long productId, Product updatedProduct) {
        Product existingProduct = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));

        existingProduct.setName(updatedProduct.getName());
        existingProduct.setPrice(updatedProduct.getPrice());
        existingProduct.setQuantity(updatedProduct.getQuantity());
        existingProduct.setCategory(updatedProduct.getCategory());

        productRepository.save(existingProduct);
    }
    
    @Transactional(readOnly = true)
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
    public Product getProductById(Long productId) {
        return productRepository.findById(productId).orElse(null);
    }
}
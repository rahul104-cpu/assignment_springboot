package com.intellipaat.xyz_mart.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.intellipaat.xyz_mart.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {


    Product findByName(String name);

    void deleteById(Long id);
    @Query("SELECT p FROM Product p INNER JOIN p.category c WHERE c.name = :categoryName")
    List<Product> findByCategory(@Param("categoryName") String categoryName);
}

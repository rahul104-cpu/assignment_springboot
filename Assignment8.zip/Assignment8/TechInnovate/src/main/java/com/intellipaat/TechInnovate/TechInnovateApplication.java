package com.intellipaat.TechInnovate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechInnovateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechInnovateApplication.class, args);
	}

}

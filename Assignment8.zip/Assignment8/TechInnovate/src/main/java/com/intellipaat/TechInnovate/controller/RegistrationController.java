 package com.intellipaat.TechInnovate.controller;
 import com.intellipaat.TechInnovate.model.User;
 import org.springframework.stereotype.Controller;
 import org.springframework.ui.Model;
 import org.springframework.validation.BindingResult;
 import org.springframework.web.bind.annotation.GetMapping;
 import org.springframework.web.bind.annotation.ModelAttribute;
 import org.springframework.web.bind.annotation.PostMapping;
 import javax.validation.Valid;

 @Controller
 public class RegistrationController {

     @GetMapping("/showForm")
     public String showRegistrationForm(Model model) {
         model.addAttribute("user", new User());
         return "registration-form";
     }

     @PostMapping("/processForm")
     public String processRegistrationForm(
             @Valid @ModelAttribute("user") User user,
             BindingResult bindingResult) {

         if (bindingResult.hasErrors()) {
             return "registration-form";
         }

         // Process the user registration (save to database, etc.)
         // For simplicity, we'll just return a confirmation message
         return "registration-confirmation";
     }
 }

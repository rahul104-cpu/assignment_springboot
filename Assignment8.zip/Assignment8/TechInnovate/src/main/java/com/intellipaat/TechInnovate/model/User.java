package com.intellipaat.TechInnovate.model;
import javax.validation.constraints.*;

public class User {
    @NotBlank(message = "Username is required")
    private String username;

    @Min(value = 18, message = "Age must be at least 18")
    private int age;

    @Email(message = "Invalid email format")
    private String email;


}

// IntelliSecureUserDetailsService.java
package com.intellipaat.IntelliSecure.security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class IntelliSecureUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Fetch user details from the database and return UserDetails
        // You may use Spring Data JPA or JDBC to fetch user details
        throw new UsernameNotFoundException("User not found with username: " + username);
    }
}

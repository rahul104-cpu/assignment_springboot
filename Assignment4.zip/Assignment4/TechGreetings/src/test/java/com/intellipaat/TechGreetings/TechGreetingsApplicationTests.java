package com.intellipaat.TechGreetings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechGreetingsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.intellipaat.TechGreetings.service;
import org.springframework.stereotype.Service;

@Service
public class DefaultGreetingService implements GreetingService {

    @Override
    public String generateGreeting() {
        return "Hello from Intellipaat Software Solution!";
    }
}

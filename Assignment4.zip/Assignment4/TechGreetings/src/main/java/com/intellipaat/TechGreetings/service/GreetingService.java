package com.intellipaat.TechGreetings.service;
public interface GreetingService {
    String generateGreeting();
}
